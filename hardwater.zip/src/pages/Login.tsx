import React, { useMemo, useState } from "react";
import { supabase } from "@/lib/supabase";

type Profession =
  | "student"
  | "fisher"
  | "researcher"
  | "utility_manager"
  | "environmental_personnel";

type Mode = "signin" | "signup" | "verify";

export default function Login() {
  const [mode, setMode] = useState<Mode>("signin");

  // Shared
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  // Sign up only fields
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [profession, setProfession] = useState<Profession>("student");

  // UI state
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);
  const [verifyEmail, setVerifyEmail] = useState<string>("");

  const redirectTo = useMemo(
    () =>
      import.meta.env.DEV
        ? "http://localhost:5173/auth/callback"
        : "https://telab.apzim.com/auth/callback",
    []
  );

  async function handleSignIn(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setInfo(null);
    try {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;
      // If your app uses a session listener to redirect, no need to do anything here.
      setInfo("Signed in. Redirecting…");
    } catch (err: any) {
      setError(err?.message ?? "Failed to sign in.");
    } finally {
      setBusy(false);
    }
  }

  async function handleSignUp(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setInfo(null);
    try {
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: redirectTo,
          data: {
            first_name: firstName,
            last_name: lastName,
            phone_number: phoneNumber,
            profession,
          },
        },
      });
      if (error) throw error;

      // Show “check your email” screen
      setVerifyEmail(email);
      setMode("verify");
    } catch (err: any) {
      setError(err?.message ?? "Failed to sign up.");
    } finally {
      setBusy(false);
    }
  }

  async function resendVerification() {
    setBusy(true);
    setError(null);
    setInfo(null);
    try {
      const { error } = await supabase.auth.resend({
        type: "signup",
        email: verifyEmail || email,
        options: { emailRedirectTo: redirectTo },
      });
      if (error) throw error;
      setInfo("Verification email re-sent. Check your inbox (and spam).");
    } catch (err: any) {
      setError(err?.message ?? "Could not resend email.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto max-w-md p-4">
      <div className="mb-4 flex rounded-xl border border-border bg-card p-1 text-sm">
        <button
          className={`flex-1 rounded-lg px-3 py-2 ${mode === "signin" ? "bg-cyan-500 font-medium" : ""}`}
          onClick={() => {
            setMode("signin");
            setError(null);
            setInfo(null);
          }}
          disabled={busy}
        >
          Sign in
        </button>
        <button
          className={`flex-1 rounded-lg px-3 py-2 ${mode === "signup" ? "bg-cyan-500 font-medium" : ""}`}
          onClick={() => {
            setMode("signup");
            setError(null);
            setInfo(null);
          }}
          disabled={busy}
        >
          Sign up
        </button>
      </div>

      {mode === "signin" && (
        <form onSubmit={handleSignIn} className="space-y-3 rounded-2xl border border-border p-4">
          <div className="grid gap-1">
            <label className="text-sm">Email</label>
            <input
              className="h-10 rounded-lg border border-border bg-background px-3"
              type="email"
              autoComplete="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              disabled={busy}
            />
          </div>
          <div className="grid gap-1">
            <label className="text-sm">Password</label>
            <input
              className="h-10 rounded-lg border border-border bg-background px-3"
              type="password"
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              disabled={busy}
            />
          </div>

          {error && <div className="rounded-md border border-red-300 bg-red-50 px-3 py-2 text-sm text-red-700">{error}</div>}
          {info && <div className="rounded-md border border-emerald-300 bg-emerald-50 px-3 py-2 text-sm text-emerald-700">{info}</div>}

          <div className="flex justify-end gap-2 pt-2">
            <button type="submit" className="h-10 rounded-xl border border-border bg-primary px-4 text-sm text-white" disabled={busy}>
              {busy ? "Signing in…" : "Sign in"}
            </button>
          </div>
        </form>
      )}

      {mode === "signup" && (
        <form onSubmit={handleSignUp} className="space-y-3 rounded-2xl border border-border p-4">
          <div className="grid gap-1">
            <label className="text-sm">First name</label>
            <input
              className="h-10 rounded-lg border border-border bg-background px-3"
              value={firstName}
              onChange={(e) => setFirstName(e.target.value)}
              required
              disabled={busy}
            />
          </div>
          <div className="grid gap-1">
            <label className="text-sm">Last name</label>
            <input
              className="h-10 rounded-lg border border-border bg-background px-3"
              value={lastName}
              onChange={(e) => setLastName(e.target.value)}
              required
              disabled={busy}
            />
          </div>
          <div className="grid gap-1">
            <label className="text-sm">Email</label>
            <input
              className="h-10 rounded-lg border border-border bg-background px-3"
              type="email"
              autoComplete="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              disabled={busy}
            />
          </div>
          <div className="grid gap-1">
            <label className="text-sm">Password</label>
            <input
              className="h-10 rounded-lg border border-border bg-background px-3"
              type="password"
              autoComplete="new-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              disabled={busy}
            />
          </div>
          <div className="grid gap-1">
            <label className="text-sm">Phone number</label>
            <input
              className="h-10 rounded-lg border border-border bg-background px-3"
              type="tel"
              autoComplete="tel"
              value={phoneNumber}
              onChange={(e) => setPhoneNumber(e.target.value)}
              disabled={busy}
            />
          </div>
          <div className="grid gap-1">
            <label className="text-sm">Profession</label>
            <select
              className="h-10 rounded-lg border border-border bg-background px-3"
              value={profession}
              onChange={(e) => setProfession(e.target.value as Profession)}
              disabled={busy}
            >
              <option value="student">Student</option>
              <option value="fisher">Fisher</option>
              <option value="researcher">Researcher</option>
              <option value="utility_manager">Utility manager</option>
              <option value="environmental_personnel">Environmental personnel</option>
            </select>
          </div>

          {error && <div className="rounded-md border border-red-300 bg-red-50 px-3 py-2 text-sm text-red-700">{error}</div>}
          {info && <div className="rounded-md border border-emerald-300 bg-emerald-50 px-3 py-2 text-sm text-emerald-700">{info}</div>}

          <div className="flex items-center justify-between pt-2">
            <button
              type="button"
              className="h-10 rounded-xl border border-border bg-card px-4 text-sm"
              onClick={() => setMode("signin")}
              disabled={busy}
            >
              Back to sign in
            </button>
            <button type="submit" className="h-10 rounded-xl border border-border bg-primary px-4 text-sm text-white" disabled={busy}>
              {busy ? "Creating account…" : "Create account"}
            </button>
          </div>
        </form>
      )}

      {mode === "verify" && (
        <div className="space-y-3 rounded-2xl border border-border p-4">
          <h2 className="text-lg font-semibold">Confirm your email</h2>
          <p className="text-sm text-muted">
            We sent a confirmation link to <span className="font-medium">{verifyEmail}</span>.
            Click the link to verify your account and sign in.
          </p>
          {error && <div className="rounded-md border border-red-300 bg-red-50 px-3 py-2 text-sm text-red-700">{error}</div>}
          {info && <div className="rounded-md border border-emerald-300 bg-emerald-50 px-3 py-2 text-sm text-emerald-700">{info}</div>}
          <div className="flex items-center justify-between pt-2">
            <button
              className="h-10 rounded-xl border border-border bg-card px-4 text-sm"
              onClick={() => setMode("signin")}
              disabled={busy}
            >
              Back to sign in
            </button>
            <button
              className="h-10 rounded-xl border border-border bg-primary px-4 text-sm text-white"
              onClick={resendVerification}
              disabled={busy}
            >
              {busy ? "Sending…" : "Resend email"}
            </button>
          </div>
          <p className="pt-1 text-xs text-muted">Tip: Check your spam/junk folder if you don’t see it.</p>
        </div>
      )}
    </div>
  );
}