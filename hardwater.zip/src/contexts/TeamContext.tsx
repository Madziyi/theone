import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { supabase } from "@/lib/supabase";

type Team = { id: string; name: string; logo_url: string | null };
type Membership = { team_id: string; role: "manager" | "member"; teams: Team | null };

type TeamCtx = {
  loading: boolean;
  userId: string | null;
  memberships: Membership[];
  teams: Team[];
  activeTeamId: string | null;
  activeTeam: Team | null;
  isManager: boolean;
  switchTeam: (teamId: string) => void;
  refresh: () => Promise<void>;
};

const Ctx = createContext<TeamCtx | null>(null);

const STORAGE_KEY = "active_team_id";

export function TeamProvider({ children }: { children: React.ReactNode }) {
  const [loading, setLoading] = useState(true);
  const [userId, setUserId] = useState<string | null>(null);
  const [memberships, setMemberships] = useState<Membership[]>([]);
  const [activeTeamId, setActiveTeamId] = useState<string | null>(
    () => localStorage.getItem(STORAGE_KEY)
  );

  async function refresh() {
    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      setUserId(user?.id ?? null);
      if (!user) {
        setMemberships([]);
        setActiveTeamId(null);
        return;
      }
      const { data } = await supabase
        .from("team_members")
        .select("team_id, role, teams:teams(id,name,logo_url)")
        .eq("user_id", user.id);

      const list = (data ?? []).filter((m) => m.teams) as Membership[];
      setMemberships(list);

      // initialize active team
      if (!activeTeamId) {
        if (list.length) {
          setActiveTeamId(list[0].team_id);
          localStorage.setItem(STORAGE_KEY, list[0].team_id);
        }
      } else {
        // if stored team no longer accessible, fall back
        if (!list.find((m) => m.team_id === activeTeamId) && list.length) {
          setActiveTeamId(list[0].team_id);
          localStorage.setItem(STORAGE_KEY, list[0].team_id);
        }
      }
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const teams = useMemo(
    () => memberships.map((m) => m.teams!).filter(Boolean),
    [memberships]
  );

  const activeTeam = useMemo(
    () => teams.find((t) => t.id === activeTeamId) ?? null,
    [teams, activeTeamId]
  );

  const isManager = useMemo(
    () => !!memberships.find((m) => m.team_id === activeTeamId && m.role === "manager"),
    [memberships, activeTeamId]
  );

  function switchTeam(teamId: string) {
    setActiveTeamId(teamId);
    localStorage.setItem(STORAGE_KEY, teamId);
  }

  const value: TeamCtx = {
    loading,
    userId,
    memberships,
    teams,
    activeTeamId,
    activeTeam,
    isManager,
    switchTeam,
    refresh,
  };

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useTeam() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useTeam must be used within <TeamProvider>");
  return ctx;
}