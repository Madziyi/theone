import { Link, NavLink } from "react-router-dom";
import TeamSwitcher from "@/components/TeamSwitcher";
import ThemeToggle from "./ThemeToggle";

export default function Header() {
  const nav = (to: string, label: string) => (
    <NavLink
      to={to}
      className={({ isActive }) =>
        `px-3 py-2 rounded-lg text-sm ${isActive ? "bg-white/10" : "hover:bg-white/5"}`
      }
    >
      {label}
    </NavLink>
  );

  return (
    <header className="sticky top-0 z-10 backdrop-blur border-b border-border bg-background/60">
      <div className="max-w-7xl mx-auto flex items-center justify-between px-4 sm:px-6 lg:px-8 h-14">
        <Link to="/" className="font-semibold">T&amp;E</Link>
        {/* Desktop nav only */}
        <nav className="hidden md:flex items-center gap-1">
          {nav("/", "Map")}
          {nav("/trends", "Trends")}
          {nav("/dashboard", "Dashboard")}
          {nav("/account", "Account")}
        </nav>
        <TeamSwitcher />
        <ThemeToggle />
      </div>
    </header>
  );
}
