import { useAuth } from "@/contexts/AuthContext";
import { useProfile } from "@/hooks/useProfile";

export default function AccountPage() {
  const { user, signOut } = useAuth();
  const { profile, loading, updateProfile } = useProfile();

  const deleteMe = async () => {
    const token = (await (await fetch("/auth/v1/token?grant_type=jwt")).json()).access_token; // not always available
    // Safer: get from supabase client:
    const { data } = await (await import("@/lib/supabase")).supabase.auth.getSession();
    const jwt = data.session?.access_token;
    if (!jwt) return alert("Missing session");
    await fetch("/functions/v1/delete-account", {
      method: "POST",
      headers: { Authorization: `Bearer ${jwt}` },
    });
    await signOut();
    window.location.assign("/");
  };

  if (!user) return <div className="p-4">Not signed in.</div>;
  if (loading || !profile) return <div className="p-4">Loading…</div>;

  return (
    <section className="mx-auto max-w-xl p-4 space-y-4">
      <h1 className="text-xl font-semibold">Account</h1>

      <div className="grid gap-3">
        <div className="text-sm">Name: <strong>{profile.first_name} {profile.last_name}</strong></div>
        <div className="text-sm">Email: <strong>{profile.email}</strong></div>

        <label className="grid gap-1 text-sm">
          <span>Phone number</span>
          <input
            className="h-10 rounded border px-2"
            defaultValue={profile.phone_number ?? ""}
            onBlur={(e) => updateProfile({ phone_number: e.target.value || null })}
          />
        </label>

        <label className="grid gap-1 text-sm">
          <span>Profession</span>
          <select
            className="h-10 rounded border px-2"
            defaultValue={profile.profession ?? ""}
            onChange={(e) => updateProfile({ profession: (e.target.value || null) as any })}
          >
            <option value="">—</option>
            <option value="student">student</option>
            <option value="fisher">fisher</option>
            <option value="researcher">researcher</option>
            <option value="utility_manager">utility manager</option>
            <option value="environmental_personnel">environmental personnel</option>
          </select>
        </label>
      </div>

      <div className="flex gap-2">
        <button className="h-10 rounded border px-3" onClick={() => signOut()}>Sign out</button>
        <button className="h-10 rounded border px-3 text-red-600" onClick={deleteMe}>
          Delete account
        </button>
      </div>
    </section>
  );
}
