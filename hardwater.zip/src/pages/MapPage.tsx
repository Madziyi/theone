import MapView from "@/components/Map/MapView";

export default function MapPage() {
  return (
    <section className="w-full">
      <MapView />
    </section>
  );
}