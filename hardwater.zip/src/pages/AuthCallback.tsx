// src/pages/AuthCallback.tsx
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import { useNavigate } from "react-router-dom";

export default function AuthCallback() {
  const nav = useNavigate();
  const [msg, setMsg] = useState("Finishing sign-in…");

  useEffect(() => {
    // For email confirmation links, GoTrue will already have verified the email.
    // If AUTOCONFIRM=false, there won’t be a session here — user signs in manually.
    // If AUTOCONFIRM=true (or "magic link" login), there may be tokens in hash.
    // We can try to refresh local session either way:
    (async () => {
      const { data } = await supabase.auth.getSession();
      if (data.session) {
        setMsg("You’re signed in. Redirecting…");
        nav("/account", { replace: true });
      } else {
        setMsg("Email confirmed. Please sign in.");
        nav("/account", { replace: true });
      }
    })();
  }, [nav]);

  return <div className="p-4 text-sm">{msg}</div>;
}
