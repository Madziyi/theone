import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/lib/supabase";

type Buoy = {
  id: number;
  buoy_id: number | string;
  name: string;
  location_nickname: string | null;
  webcam: string | null;
};

type Tile = {
  id: number;
  buoy_id: number | string;
  parameter_id: number;
  thresholds_id: number | null;
  depth: number | null;
  label: string | null;
};

type Threshold = {
  id: number;
  name: string;
  unit: string;
  ranges: { color: "green" | "yellow" | "red"; min: number | null; max: number | null }[];
};

type ParamMeta = {
  parameter_id: number;
  standard_name: string | null;
  unit: string | null;
  depth: number | null;
};

type Latest = {
  value: number | null;
  unit: string;
  timestamp: string;
};

type Column = {
  title: string;
  buoy?: Buoy;
  tiles: (Tile & { meta?: ParamMeta; latest?: Latest; threshold?: Threshold })[];
  webcam?: string | null;
};

export default function Monitor() {
  const [loading, setLoading] = useState(true);
  const [columns, setColumns] = useState<Column[]>([]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);

      // 1) Buoys (need location_nickname + webcam)
      const { data: buoysRaw, error: buoysErr } = await supabase
        .from("buoys")
        .select("id, buoy_id, name, location_nickname, webcam")
        .order("location_nickname", { ascending: true });
      if (buoysErr) { setLoading(false); return; }
      const buoys = (buoysRaw ?? []) as Buoy[];

      // 2) Tiles to show
      const { data: tilesRaw } = await supabase
        .from("monitor_tiles")
        .select("id, buoy_id, parameter_id, thresholds_id, depth, label");
      const tiles = (tilesRaw ?? []) as Tile[];

      // 3) Threshold schemes
      const { data: schemesRaw } = await supabase
        .from("monitor_thresholds")
        .select("id, name, unit, ranges");
      const schemeMap = new Map<number, Threshold>();
      (schemesRaw ?? []).forEach((t: any) => schemeMap.set(t.id, t as Threshold));

      // 4) Parameters meta for all needed parameter_ids
      const paramIds = Array.from(new Set(tiles.map(t => t.parameter_id)));
      let metaMap = new Map<number, ParamMeta>();
      if (paramIds.length) {
        const { data: paramsRaw } = await supabase
          .from("parameters")
          .select("parameter_id, standard_name, unit, depth")
          .in("parameter_id", paramIds);
        (paramsRaw ?? []).forEach((p: any) =>
          metaMap.set(Number(p.parameter_id), {
            parameter_id: Number(p.parameter_id),
            standard_name: p.standard_name,
            unit: p.unit,
            depth: p.depth ?? null,
          })
        );
      }

      // 5) Fetch latest values (1 request per tile is fine at this scale)
      const latestMap = new Map<string, Latest>(); // key: `${paramId}:${buoyId}`
      await Promise.all(
        tiles.map(async (t) => {
          const key = `${t.parameter_id}:${t.buoy_id}`;
          const { data } = await supabase
            .from("measurements")
            .select("value, timestamp")
            .eq("parameter_id", t.parameter_id)
            .eq("buoy_id", t.buoy_id)
            .order("timestamp", { ascending: false })
            .limit(1);
          const row = (data ?? [])[0] as any;
          if (row) {
            latestMap.set(key, {
              value: row.value,
              unit: row.unit ?? "",
              timestamp: row.timestamp,
            });
          }
        })
      );

      if (cancelled) return;

      // 6) Build columns grouped by location nickname
      const byLocation = new Map<string, Column>();
      for (const b of buoys) {
        const key = (b.location_nickname ?? "—").trim() || "—";
        if (!byLocation.has(key)) byLocation.set(key, { title: key, tiles: [], webcam: null });
        const col = byLocation.get(key)!;
        // Use the first buoy encountered as the "owner" of the cam, but we'll still render tiles per-buoy.
        if (!col.buoy) { col.buoy = b; col.webcam = b.webcam; }
      }

      // Attach tiles (and hydrate with meta + latest + thresholds)
      for (const t of tiles) {
        // Which column does this buoy live in?
        const buoy = buoys.find(b => String(b.buoy_id) === String(t.buoy_id));
        const locKey = buoy ? ((buoy.location_nickname ?? "—").trim() || "—") : "—";
        if (!byLocation.has(locKey)) byLocation.set(locKey, { title: locKey, tiles: [], webcam: buoy?.webcam ?? null });
        const col = byLocation.get(locKey)!;

        const meta = metaMap.get(t.parameter_id);
        const threshold = t.thresholds_id ? schemeMap.get(t.thresholds_id) : undefined;
        const latest = latestMap.get(`${t.parameter_id}:${t.buoy_id}`);
        col.tiles.push({ ...t, meta, latest, threshold });
      }

      // Keep only the three “core” tiles if you seeded more (phycocyanin / oxygen / chlorophyll)
      const wanted = ["phycocyanin", "oxygen", "chlorophyll"];
      const normalize = (s: string | null | undefined) => (s ?? "").toLowerCase();

      const cols = Array.from(byLocation.values()).map((c) => ({
        ...c,
        tiles: c.tiles
          .filter(t => {
            const lbl = normalize(t.label) || normalize(t.meta?.standard_name);
            return wanted.some(w => lbl.includes(w));
          })
          // consistent order: phycocyanin, oxygen, chlorophyll
          .sort((a, b) => {
            const rank = (x: string) =>
              normalize(x).includes("phycocyanin") ? 0 :
              normalize(x).includes("oxygen") ? 1 :
              normalize(x).includes("chlorophyll") ? 2 : 3;
            return rank(a.label ?? a.meta?.standard_name ?? "") - rank(b.label ?? b.meta?.standard_name ?? "");
          }),
      }));

      setColumns(cols);
      setLoading(false);
    })();

    return () => { cancelled = true; };
  }, []);

  return (
    <section className="mx-auto max-w-7xl p-3">
      <h1 className="mb-3 text-2xl font-semibold">Monitor</h1>

      {loading ? (
        <div className="grid h-40 place-items-center text-sm text-muted">Loading…</div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-0 border-t border-black/60">
          {columns.map((col) => (
            <div key={col.title} className="border-l border-black/60 px-3">
              {/* Column header */}
              <div className="sticky top-0 z-10 bg-background py-2">
                <h2 className="text-lg font-semibold text-center">{col.title}</h2>
              </div>

              {/* Cards */}
              <div className="mt-2 space-y-6">
                {col.tiles.map((t) => (
                  <ParamCard key={t.id} tile={t} />
                ))}
              </div>

              {/* Bottom webcam button */}
              <div className="my-6 border-t border-black/60 pt-4">
                <a
                  href={col.webcam ?? "#"}
                  target="_blank"
                  rel="noreferrer"
                  className="block rounded-xl border bg-amber-100 px-4 py-3 text-center font-medium hover:bg-amber-200 disabled:opacity-50"
                >
                  Buoy Cam Video
                </a>
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}

/* -------------------- Param Card -------------------- */

function ParamCard({ tile }: { tile: Tile & { meta?: ParamMeta; latest?: Latest; threshold?: Threshold } }) {
  const name = tile.label ?? tile.meta?.standard_name ?? `Param ${tile.parameter_id}`;
  const unitMeasured = tile.latest?.unit ?? tile.meta?.unit ?? "";
  const valRaw = tile.latest?.value ?? null;

  // If thresholds specify a different unit, convert if we know how; otherwise use raw.
  const { value, displayUnit } = normalizeToThresholdUnit(valRaw, unitMeasured, tile.threshold?.unit);

  const zone = getZone(value, tile.threshold?.ranges ?? []);
  const classes = zoneClasses(zone);

  return (
    <article className={`rounded-2xl border p-4 shadow-sm ${classes.bg} ${classes.border} ${classes.text}`}>
      <div className="text-sm font-medium">{name}</div>
      <div className="mt-2 text-2xl font-semibold">
        {value == null ? "—" : formatNumber(value)}{" "}
        <span className="text-base opacity-70">{displayUnit}</span>
      </div>
      <div className="mt-1 text-xs opacity-70">
        {tile.depth != null ? `Depth: ${tile.depth.toFixed(1)} m` : null}
      </div>
      <div className="mt-1 text-xs opacity-70">
        {tile.latest?.timestamp ? `Updated ${timeAgo(tile.latest.timestamp)}` : "No recent data"}
      </div>
    </article>
  );
}

/* -------------------- Helpers -------------------- */

function timeAgo(iso: string) {
  const ms = Date.now() - new Date(iso).getTime();
  const m = Math.floor(ms / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m} min ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h} hr${h === 1 ? "" : "s"} ago`;
  const d = Math.floor(h / 24);
  return `${d} day${d === 1 ? "" : "s"} ago`;
}

function formatNumber(v: number) {
  // No locale grouping; keep CSV-friendly dot decimals
  if (Math.abs(v) >= 100) return v.toFixed(0);
  if (Math.abs(v) >= 10) return v.toFixed(1);
  return v.toFixed(2);
}

type Zone = "green" | "yellow" | "red" | "gray";

function getZone(value: number | null, ranges: { color: string; min: number | null; max: number | null }[]): Zone {
  if (value == null) return "gray";
  for (const r of ranges) {
    const loOk = r.min == null || value >= r.min;
    const hiOk = r.max == null || value < r.max;
    if (loOk && hiOk) {
      const c = r.color.toLowerCase();
      if (c === "green" || c === "yellow" || c === "red") return c;
    }
  }
  return "gray";
}

function zoneClasses(zone: Zone) {
  switch (zone) {
    case "green":
      return { bg: "bg-emerald-50", border: "border-emerald-400", text: "text-emerald-900" };
    case "yellow":
      return { bg: "bg-yellow-50", border: "border-yellow-500", text: "text-yellow-900" };
    case "red":
      return { bg: "bg-red-50", border: "border-red-500", text: "text-red-900" };
    default:
      return { bg: "bg-gray-50", border: "border-gray-300", text: "text-gray-900" };
  }
}

/** Convert measurement value to the threshold unit, if different (supports common pairs). */
function normalizeToThresholdUnit(
  value: number | null,
  measUnit: string,
  threshUnit?: string
): { value: number | null; displayUnit: string } {
  if (value == null || !threshUnit || !measUnit) return { value, displayUnit: measUnit || threshUnit || "" };
  const from = measUnit.toLowerCase();
  const to = threshUnit.toLowerCase();
  if (from === to) return { value, displayUnit: threshUnit };

  // Minimal conversions we care about here:
  // g/L ↔ μg/L
  if (from === "g/l" && (to === "μg/l" || to === "ug/l")) return { value: value * 1_000_000, displayUnit: threshUnit };
  if ((from === "μg/l" || from === "ug/l") && to === "g/l") return { value: value / 1_000_000, displayUnit: threshUnit };

  // percent variants
  if ((from === "%" || from === "percent") && (to === "%" || to === "percent")) return { value, displayUnit: threshUnit };

  // cm/s ↔ m/s (if you later threshold speeds)
  if (from === "cm/s" && to === "m/s") return { value: value / 100, displayUnit: threshUnit };
  if (from === "m/s" && to === "cm/s") return { value: value * 100, displayUnit: threshUnit };

  // Fallback: show as measured
  return { value, displayUnit: measUnit };
}
