import { Navigate, Route, Routes } from "react-router-dom";
import MapPage from "@/pages/MapPage";
import TrendsPage from "@/pages/TrendsPage";
import Login from "@/pages/Login";
import Monitor from "@/pages/Monitor";
import AccountPage from "@/pages/AccountPage";
import AuthCallback from "./pages/AuthCallback";
import Header from "@/components/ui/Header";
import DashboardPage from "./pages/DashboardPage";
import BottomNav from "@/components/BottomNav";
import { useAuth } from "@/contexts/AuthContext";
import { useLocation } from "react-router-dom";
import { ReactNode } from "react";


function Private({ children }: { children: ReactNode }) {
  const { user, loading } = useAuth();
  if (loading) return null;
  return user ? children : <Navigate to="/login" replace />;
}

export default function App() {
  const { pathname } = useLocation();
  const mainClass = pathname === "/" ? "p-0" : "px-4 sm:px-6 lg:px-8 py-4 pb-24 sm:pb-6";
  return (
    <div className="min-h-dvh bg-background">
      <Header />
      <main className={mainClass}>
        <Routes>
          <Route path="/" element={<MapPage />} />
          <Route path="/trends" element={<TrendsPage />} />
          <Route path="/monitor" element={<Monitor />} />
          <Route path="/dashboard" element={<DashboardPage />} />
          <Route path="/login" element={<Login />} />
          <Route path="/auth/callback" element={<AuthCallback />} />
          <Route
            path="/account"
            element={
              <Private>
                <AccountPage />
              </Private>
            }
          />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
      <BottomNav />
    </div>
  );
}
