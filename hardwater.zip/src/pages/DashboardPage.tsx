import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/lib/supabase";
import { useTeam } from "@/contexts/TeamContext";

type TeamRow = { id: string; name: string; logo_url: string | null };
type Buoy = { id: string; buoy_id: number; name: string; latitude?: number; longitude?: number; location_nickname?: string | null };
type Profile = {
  id: string;
  email: string | null;
  first_name: string;
  last_name: string;
  phone_number: string | null;
  profession: "student" | "fisher" | "researcher" | "utility_manager" | "environmental_personnel" | null;
};

const PROFESSIONS = [
  "student",
  "fisher",
  "researcher",
  "utility_manager",
  "environmental_personnel",
] as const;

export default function DashboardPage() {
  const { userId, loading: teamLoading, activeTeam, activeTeamId, memberships, isManager } = useTeam();

  const [buoys, setBuoys] = useState<Buoy[]>([]);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [saving, setSaving] = useState(false);
  const [saveMsg, setSaveMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Invite form
  const [inviteEmail, setInviteEmail] = useState("");
  const [inviteRole, setInviteRole] = useState<"member" | "manager">("member");
  const [inviteFirst, setInviteFirst] = useState("");
  const [inviteLast, setInviteLast] = useState("");
  const [inviting, setInviting] = useState(false);
  const [inviteMsg, setInviteMsg] = useState<string | null>(null);
  const [inviteErr, setInviteErr] = useState<string | null>(null);

  // Load buoys for active team via team_buoys → buoys
  useEffect(() => {
    (async () => {
      if (!activeTeamId) {
        setBuoys([]);
        return;
      }
      const { data, error } = await supabase
        .from("team_buoys")
        .select("buoy_id")
        .eq("team_id", activeTeamId)
        .order("created_at", { ascending: true });

      if (error) {
        setBuoys([]);
        return;
      }
      const list = (data ?? [])
        .map((r: any) => r.buoys)
        .filter(Boolean) as Buoy[];
      setBuoys(list);
    })();
  }, [activeTeamId]);

  // Load profile
  useEffect(() => {
    (async () => {
      if (!userId) return;
      const { data: p } = await supabase
        .from("profiles")
        .select("id, email, first_name, last_name, phone_number, profession")
        .eq("id", userId)
        .maybeSingle();
      if (p) setProfile(p as Profile);
    })();
  }, [userId]);

  async function saveProfile() {
    if (!profile || !userId) return;
    setSaving(true);
    setErrorMsg(null);
    setSaveMsg(null);
    try {
      const { error } = await supabase
        .from("profiles")
        .update({
          first_name: profile.first_name ?? "",
          last_name: profile.last_name ?? "",
          phone_number: profile.phone_number ?? null,
          profession: profile.profession ?? null,
        })
        .eq("id", userId);
      if (error) throw error;
      setSaveMsg("Saved!");
      setTimeout(() => setSaveMsg(null), 1500);
    } catch (e: any) {
      setErrorMsg(e?.message ?? "Failed to save");
    } finally {
      setSaving(false);
    }
  }

  async function deleteAccount() {
    if (!userId) return;
    if (!window.confirm("This will permanently delete your account. Continue?")) return;

    try {
      const { data: { session } } = await supabase.auth.getSession();
      const token = session?.access_token;
      if (!token) throw new Error("Not signed in");

      const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/delete-account`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          apikey: import.meta.env.VITE_SUPABASE_ANON_KEY,
        },
      });

      const j = await res.json().catch(() => null);
      if (!res.ok) throw new Error(j?.error || "Delete failed");

      await supabase.auth.signOut();
      window.location.href = "/";
    } catch (e: any) {
      alert(e?.message ?? "Delete failed");
    }
  }

  async function sendInvite() {
    if (!activeTeamId) return;
    setInviting(true);
    setInviteMsg(null);
    setInviteErr(null);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const token = session?.access_token;
      if (!token) throw new Error("Not signed in");

      const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/invite-user`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          apikey: import.meta.env.VITE_SUPABASE_ANON_KEY,
        },
        body: JSON.stringify({
          email: inviteEmail,
          team_id: activeTeamId,
          role: inviteRole,
          first_name: inviteFirst,
          last_name: inviteLast,
        }),
      });

      const j = await res.json();
      if (!res.ok) throw new Error(j?.error || "Invite failed");
      setInviteMsg("Invite sent. The user will receive an email to join the team.");
      setInviteEmail("");
      setInviteFirst("");
      setInviteLast("");
      setInviteRole("member");
      setTimeout(() => setInviteMsg(null), 2500);
    } catch (e: any) {
      setInviteErr(e?.message ?? "Invite failed");
    } finally {
      setInviting(false);
    }
  }

  const teamRoleText = useMemo(() => {
    const m = memberships.find((mm) => mm.team_id === activeTeamId);
    return m?.role === "manager" ? "Manager" : "Member";
  }, [memberships, activeTeamId]);

  return (
    <section className="mx-auto max-w-6xl space-y-6">
      {/* Team header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          {activeTeam?.logo_url ? (
            <img src={activeTeam.logo_url} alt="Team logo" className="h-10 w-10 rounded-full object-contain" />
          ) : (
            <div className="h-10 w-10 rounded-full bg-primary/20" />
          )}
          <div>
            <div className="text-lg font-semibold">{activeTeam?.name ?? "My Team"}</div>
            <div className="text-xs text-muted">{teamLoading ? "Loading…" : teamRoleText}</div>
          </div>
        </div>

        {/* Quick sign-out */}
        <button
          className="h-9 rounded-lg border border-border bg-card px-3 text-sm"
          onClick={async () => {
            await supabase.auth.signOut();
            window.location.href = "/";
          }}
        >
          Sign out
        </button>
      </div>

      {/* Buoys quick links */}
      <div className="space-y-2">
        <div className="text-sm font-semibold">Team buoys</div>
        {buoys.length === 0 ? (
          <div className="rounded-2xl border border-border p-4 text-sm text-muted">
            No buoys found for this team.
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 md:grid-cols-3">
            {buoys.map((b) => (
              <article key={b.id} className="rounded-2xl border border-border bg-card p-3">
                <div className="font-medium">{b.name}</div>
                <div className="mt-1 text-xs text-muted">{b.location_nickname ?? ""}</div>
                <div className="mt-2 flex gap-2">
                  <Link
                    className="inline-flex h-9 items-center rounded-lg border border-border bg-background px-3 text-sm"
                    to={`/realtime?buoy=${encodeURIComponent(String(b.buoy_id))}`}
                  >
                    Realtime
                  </Link>
                  <Link
                    className="inline-flex h-9 items-center rounded-lg border border-border bg-background px-3 text-sm"
                    to={`/trends?buoy=${encodeURIComponent(String(b.buoy_id))}`}
                  >
                    Trends
                  </Link>
                </div>
              </article>
            ))}
          </div>
        )}
      </div>

      {/* Settings / Profile */}
      <div className="grid gap-4 md:grid-cols-2">
        <section className="rounded-2xl border border-border bg-card p-4">
          <div className="text-sm font-semibold">Settings</div>
          {!profile ? (
            <div className="mt-2 text-sm text-muted">Loading profile…</div>
          ) : (
            <div className="mt-3 grid gap-3">
              <label className="grid gap-1 text-sm">
                <span className="text-muted">Email</span>
                <input
                  className="h-10 rounded-lg border border-border bg-background px-2"
                  value={profile.email ?? ""}
                  disabled
                />
              </label>
              <div className="grid gap-3 sm:grid-cols-2">
                <label className="grid gap-1 text-sm">
                  <span className="text-muted">First name</span>
                  <input
                    className="h-10 rounded-lg border border-border bg-background px-2"
                    value={profile.first_name ?? ""}
                    onChange={(e) => setProfile({ ...(profile as Profile), first_name: e.target.value })}
                  />
                </label>
                <label className="grid gap-1 text-sm">
                  <span className="text-muted">Last name</span>
                  <input
                    className="h-10 rounded-lg border border-border bg-background px-2"
                    value={profile.last_name ?? ""}
                    onChange={(e) => setProfile({ ...(profile as Profile), last_name: e.target.value })}
                  />
                </label>
              </div>
              <label className="grid gap-1 text-sm">
                <span className="text-muted">Phone number</span>
                <input
                  className="h-10 rounded-lg border border-border bg-background px-2"
                  value={profile.phone_number ?? ""}
                  onChange={(e) => setProfile({ ...(profile as Profile), phone_number: e.target.value })}
                />
              </label>
              <label className="grid gap-1 text-sm">
                <span className="text-muted">Profession</span>
                <select
                  className="h-10 rounded-lg border border-border bg-background px-2"
                  value={profile.profession ?? ""}
                  onChange={(e) =>
                    setProfile({
                      ...(profile as Profile),
                      profession: (e.target.value || null) as Profile["profession"],
                    })
                  }
                >
                  <option value="">—</option>
                  {PROFESSIONS.map((p) => (
                    <option key={p} value={p}>
                      {p.replace("_", " ")}
                    </option>
                  ))}
                </select>
              </label>

              {errorMsg && (
                <div className="rounded-md border border-red-300 bg-red-50 px-3 py-2 text-sm text-red-700">
                  {errorMsg}
                </div>
              )}
              {saveMsg && (
                <div className="rounded-md border border-emerald-300 bg-emerald-50 px-3 py-2 text-sm text-emerald-700">
                  {saveMsg}
                </div>
              )}

              <div className="mt-1 flex justify-end gap-2">
                <button
                  className="h-10 rounded-xl border border-border bg-card px-4 text-sm"
                  onClick={saveProfile}
                  disabled={saving}
                >
                  {saving ? "Saving…" : "Save changes"}
                </button>
                <button
                  className="h-10 rounded-xl border border-border bg-background px-4 text-sm"
                  onClick={deleteAccount}
                >
                  Delete account
                </button>
              </div>
            </div>
          )}
        </section>

        {/* Manager Tools */}
        <section className="rounded-2xl border border-border bg-card p-4">
          <div className="text-sm font-semibold">Manager tools</div>
          {!isManager ? (
            <div className="mt-2 text-sm text-muted">Only managers can invite users.</div>
          ) : (
            <div className="mt-3 grid gap-3">
              <label className="grid gap-1 text-sm">
                <span className="text-muted">Invite email</span>
                <input
                  className="h-10 rounded-lg border border-border bg-background px-2"
                  type="email"
                  value={inviteEmail}
                  onChange={(e) => setInviteEmail(e.target.value)}
                  placeholder="person@example.com"
                />
              </label>
              <div className="grid gap-3 sm:grid-cols-2">
                <label className="grid gap-1 text-sm">
                  <span className="text-muted">First name (optional)</span>
                  <input
                    className="h-10 rounded-lg border border-border bg-background px-2"
                    value={inviteFirst}
                    onChange={(e) => setInviteFirst(e.target.value)}
                  />
                </label>
                <label className="grid gap-1 text-sm">
                  <span className="text-muted">Last name (optional)</span>
                  <input
                    className="h-10 rounded-lg border border-border bg-background px-2"
                    value={inviteLast}
                    onChange={(e) => setInviteLast(e.target.value)}
                  />
                </label>
              </div>
              <label className="grid gap-1 text-sm">
                <span className="text-muted">Role</span>
                <select
                  className="h-10 rounded-lg border border-border bg-background px-2"
                  value={inviteRole}
                  onChange={(e) => setInviteRole(e.target.value as "member" | "manager")}
                >
                  <option value="member">Member</option>
                  <option value="manager">Manager</option>
                </select>
              </label>

              {inviteErr && (
                <div className="rounded-md border border-red-300 bg-red-50 px-3 py-2 text-sm text-red-700">
                  {inviteErr}
                </div>
              )}
              {inviteMsg && (
                <div className="rounded-md border border-emerald-300 bg-emerald-50 px-3 py-2 text-sm text-emerald-700">
                  {inviteMsg}
                </div>
              )}

              <div className="mt-1 flex justify-end">
                <button
                  className="h-10 rounded-xl border border-border bg-primary px-4 text-sm text-white"
                  onClick={sendInvite}
                  disabled={inviting || !inviteEmail || !activeTeamId}
                >
                  {inviting ? "Sending…" : "Send invite"}
                </button>
              </div>
            </div>
          )}
        </section>
      </div>
    </section>
  );
}